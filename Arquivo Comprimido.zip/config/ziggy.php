<?php

return [
    // ... (outras configurações que possam estar aqui)

    'groups' => [
        'api' => ['api/*'], // <- ADICIONE ESTA LINHA
    ],
];